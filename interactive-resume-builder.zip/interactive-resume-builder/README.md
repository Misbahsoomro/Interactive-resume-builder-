# Interactive resume builder 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Misbahsoomro/pen/NWZeJNV](https://codepen.io/Misbahsoomro/pen/NWZeJNV).

