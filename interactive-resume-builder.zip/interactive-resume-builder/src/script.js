document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('resume-form') as HTMLFormElement;
    const resumeOutput = document.getElementById('resume-output') as HTMLDivElement;
    const resumeContent = document.getElementById('resume-content') as HTMLDivElement;
    const editResumeButton = document.getElementById('edit-resume') as HTMLButtonElement;
    const toggleSkillsButton = document.getElementById('toggle-skills') as HTMLButtonElement;
    const skillsSection = document.getElementById('skills-section') as HTMLDivElement;

    toggleSkillsButton.addEventListener('click', () => {
        skillsSection.classList.toggle('hidden');
    });

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const name = (document.getElementById('name') as HTMLInputElement).value;
        const email = (document.getElementById('email') as HTMLInputElement).value;
        const phone = (document.getElementById('phone') as HTMLInputElement).value;
        const education = (document.getElementById('education') as HTMLTextAreaElement).value;
        const experience = (document.getElementById('experience') as HTMLTextAreaElement).value;
        const skills = (document.getElementById('skills') as HTMLTextAreaElement).value;

        resumeContent.innerHTML = `
            <h3>${name}</h3>
            <p>Email: ${email}</p>
            <p>Phone: ${phone}</p>
            <h4>Education</h4>
            <p>${education}</p>
            <h4>Work Experience</h4>
            <p>${experience}</p>
            <h4>Skills</h4>
            <p>${skills}</p>
        `;

        resumeOutput.classList.remove('hidden');
        form.reset();
    });

    editResumeButton.addEventListener('click', () => {
        resumeOutput.classList.add('hidden');
    });
});
